//
//  JioAdsFramework.h
//  JioAdsFramework
//
//  Created by Amit Bongulwar on 27/08/20.
//  Copyright © 2020 jioAds. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "ViewPortHandler_Extension.h"
#import "JSInterface.h"
#import "WKJSProxyDelegate.h"
#import "ZHSWKWebView.h"
//! Project version number for JioAdsFramework.
FOUNDATION_EXPORT double JioAdsFrameworkVersionNumber;

//! Project version string for JioAdsFramework.
FOUNDATION_EXPORT const unsigned char JioAdsFrameworkVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <JioAdsFramework/PublicHeader.h>

//typedef NS_ENUM(NSInteger, AdPodVariant)
//{
//    DEFAULT_ADPOD,
//    INFINITE_AD_DURATION_WITH_LOOP
//};

